#!/bin/sh -x

appid=sfc_support
this_path="$(dirname $(realpath $0))"
fworkpath="$this_path/${appid}_workpath"

mft_dir_name="${appid}_manifests"
ke_mft_dir="/etc/kubeedge/manifests"
sta_running="running"
sta_stopping="stopping"
sta_stopfail="stopfail"
sta_stopped="stopped"
fcurrent_ver="${appid}_current_version"
fcurrent_state="${appid}_current_state"
fver_hist="${appid}_version_history"
fsts_read="sts_${appid}_read"
fsts_reconf="sts_${appid}_reconf"
fsts_upgrade="sts_${appid}_upgrade"
fsts_rollback="sts_${appid}_rollback"
flog_opr="${appid}_log_opr"
flog_tmr_err="${appid}_log_tmr_err"

# 操作类型
log_action_install="00H"
log_action_start="01H"
log_action_stop="02H"
log_action_unins="03H"
log_action_default="FFH"

# 操作状态
log_state_inprocess="00H"
log_state_completed="01H"
log_state_failed="02H"
log_state_default="FFH"

# 网口  todo 真实环境要改成 bond0.1000
interface="bond0"
interface2="bond0.1000"
interface3="bond0.1001"

# 添加IP，如不需要添加IP，可把此值改为false
add_ip="true"

sfc_sup_pkg="sfc_sup_pkg"
# sfc应用安装目录
sfc_dir="sfc"
# support应用安装目录
support_pkg_dir="support"

# sfc压缩包正则匹配的文件名，兼容文件名版本号改变的情况。文件名示例：SFC_AMF_V0.0.99_aarch64.tgz
SFC_FILE_NAME="SFC_AMF_.*\.tgz$"
# support压缩包正则匹配的文件名，兼容版本号动态改变的情况。文件名示例：SUPPORT_APP_v2.0.0_Linux_aarch64.tgz
SUPPORT_FILE_NAME="SUPPORT_APP_.*\.tgz$"

# 网口检测告警写入时间(秒)
alarm_time=180
# 告警文件目录
alarm_file="/nvme/nvme0n1p1/fm/fm.json"
# 告警文件大于50M，删除文件，重新建立
alerm_file_threshold=$((50 * 1024 * 1024))

# 设置工作目录
setpath() {
  local path1=$1
  local path2=$2
  local path3=$3

  if [ -z "$path1" ]; then
    return 1
  fi

  mkdir -p $path1

  echo "path1=$(realpath "$path1")" > "$fworkpath"
  echo "path2=$(realpath "$path2" 2>/dev/null)" >> "$fworkpath"
  echo "path3=$(realpath "$path3" 2>/dev/null)" >> "$fworkpath"
  _tmr_pipeline2 "$fworkpath" "$fworkpath.2" "$fworkpath.3" "1" 2>/dev/null
}

# 文件处理
readfile() {
  local srcpath_file=$1

  # 接口文档新加以下2个参数，暂未用到，先不处理
  local ftype=$2     # 文件类型
  local fsubtype=$3  # 文件子类型

  local main_path=$(_getpath 1)
  mkdir -p "$main_path/$sfc_sup_pkg" && cp -f "$srcpath_file" "$main_path/$sfc_sup_pkg"

  local sts="$this_path/$fsts_read"
  _fwrite "$sts" "11H"
}

# 检查文件读取结果
chkread() {
  local sts="$this_path/$fsts_read"
  if [ ! -s "$sts" ]; then
    return 1
  fi

  local ret
  ret=$(_fread "$sts")
  [ $? -eq 0 ] || return 1
  if [ "$ret" != 00H ]; then
    _tmr_fdel "$sts" >/dev/null 2>&1
  fi

  echo $ret
}

# 计算是否3分钟的时间秒数
is_time_up() {
  local count=$1
  local remainder=$(expr $count % $alarm_time)
  if [ "$remainder" -eq 0 ]; then
      return 0
  else
      return 1
  fi
}

#删除大于阈值的告警文件
cleanup_large_file() {
  if [ -e "$alarm_file" ]; then
    local file_size=$(stat -c %s "$alarm_file")
    if [ "$file_size" -gt "$alerm_file_threshold" ]; then
        rm -f "$alarm_file"
    fi
  fi
}

# 告警写入文件
alarm_write() {
  local interface_val=$1

  #判断告警文件大于阈值，删除文件
  cleanup_large_file
  _fwrite "$alarm_file" "$(date +"%Y-%m-%d %H:%M:%S") ${interface_val} down" 1
}

# 检查网络接口状态是否UP
wait_interface_up() {
  local count=0
  while ! ip link show "$interface" | grep -q "state UP"; do
    # 启动网口
    startInterface

    count=$((count + 5))
    # 计算是否到时间
    if is_time_up $count; then
      # 告警写入文件中
      alarm_write "$interface"
    fi

    sleep 5
  done

  while ! ip link show "$interface2" | grep -q "state UP"; do
    # 启动网口
    startInterface
    count=$((count + 5))
    # 计算是否到时间
    if is_time_up $count; then
      # 告警写入文件中
      alarm_write "$interface2"
    fi
    sleep 5
  done

  while ! ip link show "$interface3" | grep -q "state UP"; do
    # 启动网口
    startInterface
    count=$((count + 5))
    # 计算是否到时间
    if is_time_up $count; then
      # 告警写入文件中
      alarm_write "$interface3"
    fi
    sleep 5
  done
  return 0
}

# 安装应用
install(){
  local version=$1

  _log_opr "$log_action_install" "$log_state_inprocess"
  local main_path=$(_getpath 1)
  local sfc_sup_pkg_path="$main_path/$sfc_sup_pkg"

  tar -xzf "$sfc_sup_pkg_path/$version" -C "$sfc_sup_pkg_path"

  local sfc_path="${main_path}/${sfc_dir}"

  mkdir -p "$sfc_path"

  sfc_file=$(ls $sfc_sup_pkg_path | grep "${SFC_FILE_NAME}")
  support_file=$(ls $sfc_sup_pkg_path | grep "${SUPPORT_FILE_NAME}")

  sfc_path_file="${sfc_sup_pkg_path}/$sfc_file"
  support_path_file="${sfc_sup_pkg_path}/$support_file"

  # sfc解压，还没安装
  tar -xzf $sfc_path_file -C "$sfc_sup_pkg_path"
  # support 解压相当于安装
  tar -xzf $support_path_file -C "$main_path"

  cp -r "$main_path/support/tmr" "$main_path"

  # 安装 sfc
  cd "${sfc_sup_pkg_path}/image" && chmod +x ngc-amf.sh && ./ngc-amf.sh install "$sfc_path"

  # 三模构建
  sfc_sup_tmr_store

  _fwrite "${sfc_sup_pkg_path}/${fcurrent_ver}" "$version"
  _log_opr "$log_action_install" "$log_state_completed"

  return 0
}

# 获取当前版本信息
getver() {
  local main_path=$(_getpath 1)
  local sfc_sup_pkg_path="$main_path/$sfc_sup_pkg"
  local current
  current=$(_fread "${sfc_sup_pkg_path}/${fcurrent_ver}")
  if [ $? != 0 ]; then
    return 1
  fi

  echo "1" "$current"
}

# 使用support中tmr命令创建三模
sfc_sup_tmr_store(){
  local main_path=$(_getpath 1)
  local sfc_path="${main_path}/${sfc_dir}"

  #sfc三模备份
  local config="${sfc_path}/config/*"
  use_support_tmr_store "$config"

  local bin="${sfc_path}/bin/*"
  use_support_tmr_store "$bin"

  local redis="${sfc_path}/redis/*"
  use_support_tmr_store "$redis"

  use_support_tmr_store "${sfc_path}/ngc-amf.sh" 2>/dev/null
  use_support_tmr_store "${sfc_path}/version" 2>/dev/null
  use_support_tmr_store "${sfc_path}/amf_install.conf" 2>/dev/null

  # support 三模备份
  local support_pkg_path="${main_path}/support"
  local supconf="${support_pkg_path}/supconf/*"
  use_support_tmr_store "$supconf" 2>/dev/null

  local scripts="${support_pkg_path}/scripts/*"
  use_support_tmr_store "$scripts" 2>/dev/null

  use_support_tmr_store "${support_pkg_path}/s-5gc-support" 2>/dev/null
  use_support_tmr_store "${support_pkg_path}/tmr" 2>/dev/null

  use_support_tmr_store "${main_path}/tmr" 2>/dev/null

  return 0
}

# 使用support中tmr命令检查三模一致性
sfc_sup_tmr_validate(){
  local main_path=$(_getpath 1)
  local sfc_path="${main_path}/${sfc_dir}"

  local support_pkg_path="${main_path}/support"
#  use_support_tmr_validate "${support_pkg_path}/tmr" 2>/dev/null
  use_support_tmr_validate "${main_path}/tmr" 2>/dev/null
  use_SFC_tmr_validate 2>/dev/null

  #sfc三模一致性检查
  local config="${sfc_path}/config/*"
  use_support_tmr_validate "$config"

  local bin="${sfc_path}/bin/*"
  use_support_tmr_validate "$bin"

  local redis="${sfc_path}/redis/*"
  use_support_tmr_validate "$redis"

  use_support_tmr_validate "${sfc_path}/ngc-amf.sh" 2>/dev/null
  use_support_tmr_validate "${sfc_path}/version" 2>/dev/null
  use_support_tmr_validate "${sfc_path}/amf_install.conf" 2>/dev/null

  # support 三模一致性检查
  local supconf="${support_pkg_path}/supconf/*"
  use_support_tmr_validate "$supconf"

  local scripts="${support_pkg_path}/scripts/*"
  use_support_tmr_validate "$scripts"

  use_support_tmr_validate "${support_pkg_path}/s-5gc-support" 2>/dev/null


  return 0
}

# 启动网口
startInterface(){
  ip link set bond0 up
  ip link set bond0.1000 up
  ip link set bond0.1001 up
}

# 添加ip和路由
addiproute(){
  #添加N2 IP地址
  ip -6 addr add 2420:aaaa:203:5:2:100:0:2/112 dev bond0.1000

  #添加路由配置
  ip -6 route add 2420:aaaa:203:5:1:100::/112 via 2420:aaaa:203:5:2:100:0:1 dev bond0.1000 #业务口到基站的路由
  ip -6 route add 2420:aaaa:203:5:4::/112 via 2420:aaaa:203:5:6::1 dev bond0.1001 #管理口到星载网管的路由
  ip -6 r add default via 2420:aaaa:203:5:6::1 #管理口到OMC的路由，默认路由底

  ip addr add 172.16.0.1/24 dev "$interface"
}

# 初始化启动；做一些网口状态检查和网络配置
initAndStart(){
  _log_opr "$log_action_start" "$log_state_inprocess"
#  if [ "$add_ip" = "true" ]; then
#    #ip -6 addr add 2420:aaaa:203:6:2:100:0:2/112 dev "$interface"
#    ip addr add 172.16.0.1/24 dev "$interface"
#  fi
  startuppro
}

# 启动应用
startuppro() {
  # 检查和等待网口启动
  wait_interface_up
  # 添加ip和路由
  addiproute

  sleep 5

  #软连接
  ln -sfn /nvme/nvme0n1p1/workspace /workspace

  _log_opr "$log_action_start" "$log_state_inprocess"
  local main_path=$(_getpath 1)

  # 三模一致性检查
  sfc_sup_tmr_validate

  # 启动support
  local support_bin_path="${main_path}/support"
  chmod +x "$support_bin_path/s-5gc-support"
  chmod +x "$support_bin_path/start_support.sh"
  local support_log="${support_bin_path}/support.log"
  cd $support_bin_path 
  ${main_path}/support/s-5gc-support I07vUs+Nm82mXH2s >> /dev/null 2>&1 &

  # 启动sfc
  chmod +x "${main_path}/$sfc_dir/ngc-amf.sh"
  nohup "${main_path}/$sfc_dir/ngc-amf.sh" start >"${main_path}/$sfc_dir/ngc-amf.log" 2>&1 &

  _set_state "$sta_running"
  _log_opr "$log_action_start" "$log_state_completed"
  return 0
}


# 停止应用，不会删除相关文件
stoppro() {
  _log_opr "$log_action_stop" "$log_state_inprocess"

  # 停止老的SFC进程
  pkill -9 sfc

  local main_path=$(_getpath 1)
  local sfc_path="${main_path}/$sfc_dir"
  #停止 sfc
  "${sfc_path}/ngc-amf.sh" stop

  #停止support
  stop_support

  _set_state "$sta_stopped"
  _log_opr "$log_action_stop" "$log_state_completed"
  return 0
}

stop_support(){
  killall s-5gc-support
}

# 卸载应用
uninstall() {
  _log_opr "$log_action_unins" "$log_state_inprocess"

  stoppro

  local main_path=$(_getpath 1)

  local sfc_sup_pkg_path="$main_path/$sfc_sup_pkg"
  find $sfc_sup_pkg_path -type f -regex ".*/${SFC_FILE_NAME}" -delete
  find $sfc_sup_pkg_path -type f -regex ".*/${SUPPORT_FILE_NAME}" -delete

  cd $main_path && rm -fr sfc_bk && mv $sfc_dir sfc_bk >/dev/null 2>&1
  cd $main_path && rm -fr support_bk && mv support support_bk >/dev/null 2>&1

  _log_opr "$log_action_unins" "$log_state_completed"
  return 0
}

# 重构开始接口
prereconfig() {
	echo "00H"
}

# 重构应用
reconfig() {
  local srcpath=$1

  local sts="$this_path/$fsts_reconf"
  {
    _fwrite "$sts" "11H"

    uninstall
    if [ $? != 0 ]; then
      _fwrite "$sts" "FFH"
      return 1
    fi

    install "$srcpath"
    if [ $? != 0 ]; then
      _fwrite "$sts" "FFH"
      return 1
    fi

    startuppro
    if [ $? != 0 ]; then
      _fwrite "$sts" "FFH"
      return 1
    fi
    _fwrite "$sts" "00H"
  } &
}

# 检查重构结果
chkreconfig() {
  local sts="$this_path/$fsts_reconf"
  if [ ! -s "$sts" ]; then
    return 1
  fi

  local ret
  ret=$(_fread "$sts")
  [ $? -eq 0 ] || return 1
  if [ "$ret" != 11H ]; then
    _tmr_fdel "$sts" >/dev/null 2>&1
  fi

  echo $ret
}

# 操作日志记录
_log_opr() {
  local action=$1
  local state=$2

  _fwrite "$this_path/$flog_opr" "${action} ${state}" 1
}

# 获取工作目录
_getpath() {
  local main_path=${1:-0}
  if ! _tmr_pipeline2 "$fworkpath" "$fworkpath.2" "$fworkpath.3" "0" 2>/dev/null; then
    return 1
  fi
  local paths=$(cat "$fworkpath")
  local p1=$(echo "$paths" | sed -n 's/path1=//p')
  local p2=$(echo "$paths" | sed -n 's/path2=//p')
  local p3=$(echo "$paths" | sed -n 's/path3=//p')
  if [ "$main_path" -eq 1 ]; then
    echo "$p1"
    return
  fi
  echo "$p1" "$p2" "$p3"
}

# 错误日志
_log_tmr_err() {
  local err=$1

  echo "$(date): $err" >> "$this_path/$flog_tmr_err"
}

# 文件删除
_tmr_fdel() {
  local f=$1
  if [ ! -e "$f" ]; then
    return
  fi
  local dup_paths=$(_get_tmr_path "$f")
  local p2="$(echo "$dup_paths" | cut -d' ' -f1)"
  local p3="$(echo "$dup_paths" | cut -d' ' -f2)"
  if [ -e "$p2" ]; then
    rm -rf "$p2"
  fi
  if [ -e "$p3" ]; then
    rm -rf "$p3"
  fi
  rm -rf "$f"
}

# 三模创建
_tmr_pipeline() {
  local f=$1
  local p2=$2
  local p3=$3
  local force=${4:-0}

  if [ ! -f "$f" ] || [ -e "$f.broken" ]; then
    return 1
  fi

  if [ -z "$p2" ]; then
    local dup_paths
    dup_paths=$(_get_tmr_path "$f")
    if [ $? != 0 ]; then
      _log_tmr_err "get tmr path failed [$f]"
      return 1
    fi
    p2="$(echo "$dup_paths" | cut -d' ' -f1)"
    p3="$(echo "$dup_paths" | cut -d' ' -f2)"
  fi
  if [ "$force" -eq 1 ]; then
    rm -f "$p2" "$p3"
  fi

  _do_tmr "$f" "$p2" "$p3"
  if [ $? != 0 ]; then
    _log_tmr_err "tmr failed [$f]"
    return 1
  fi
  local msg
  msg=$(_tmr_chk "$f" "$p2" "$p3" 5 2>&1)
  if [ $? -eq 0 ]; then
    return 0
  else
    if [ ! -z "$msg" ]; then
      _log_tmr_err "check failed [$f]"
      mv "$f" "${f}.broken"
      rm -f "$p2" "$p3"
    fi
    return 1
  fi
}

# 使用support中tmr命令创建三模
use_support_tmr_store() {
  local f=$1

  local main_path=$(_getpath 1)
  local support_tmr="${main_path}/support/tmr"
  $support_tmr store ${f} >/dev/null 2>&1

  return 0
}

# 使用support 中 tmr 命令检查三模一致性
use_support_tmr_validate(){
  local f=$1

  local main_path=$(_getpath 1)
  local support_tmr="${main_path}/support/tmr"
  $support_tmr validate ${f} >/dev/null 2>&1
#  $support_tmr validate ${f}

  return 0
}

# 使用SFC 中 tmr 命令检查三模一致性
use_SFC_tmr_validate(){
  local main_path=$(_getpath 1)
  local SFC_tmr="${main_path}/tmr"

  local support_tmr="${main_path}/support/tmr"
  $SFC_tmr validate ${support_tmr} >/dev/null 2>&1
#  $SFC_tmr validate ${support_tmr}

  return 0
}

# 手动做三模
oldtmrstore() {
  local f=$1

  if [ ! -f "$f" ] || [ -e "$f.broken" ]; then
    return 1
  fi

  local dup_paths
  dup_paths=$(_get_tmr_path "$f")
  if [ $? != 0 ]; then
    _log_tmr_err "get tmr path failed [$f]"
    return 1
  fi
  local p2="$(echo "$dup_paths" | cut -d' ' -f1)"
  local p3="$(echo "$dup_paths" | cut -d' ' -f2)"

  rm -f "$p2" "$p3"

  _do_tmr "$f" "$p2" "$p3"
  if [ $? != 0 ]; then
    _log_tmr_err "tmr failed [$f]"
    return 1
  fi
  return 0
}

# 手动做三模
tmrstore() {
  local f=$1
  use_support_tmr_store "${f}"
  return 0
}

# 三模创建 backup创建写入appid标签
_tmr_pipeline2() {
  local f=$1
  local p2=$2
  local p3=$3
  local force=${4:-0}

  if [ ! -f "$f" ] || [ -e "$f.broken" ]; then
    return 1
  fi

  if [ -z "$p2" ]; then
    local dup_paths
    dup_paths=$(_get_tmr_path2 "$f")
    if [ $? != 0 ]; then
      _log_tmr_err "get tmr path failed [$f]"
      return 1
    fi
    p2="$(echo "$dup_paths" | cut -d' ' -f1)"
    p3="$(echo "$dup_paths" | cut -d' ' -f2)"
  fi
  if [ "$force" -eq 1 ]; then
    rm -f "$p2" "$p3"
  fi

  _do_tmr "$f" "$p2" "$p3"
  if [ $? != 0 ]; then
    _log_tmr_err "tmr failed [$f]"
    return 1
  fi
  local msg
  msg=$(_tmr_chk "$f" "$p2" "$p3" 5 2>&1)
  if [ $? -eq 0 ]; then
    return 0
  else
    if [ ! -z "$msg" ]; then
      _log_tmr_err "check failed [$f]"
      mv "$f" "${f}.broken"
      rm -f "$p2" "$p3"
    fi
    return 1
  fi
}

# 获取三模备份内容
_get_tmr_path() {
  local f=$1

  f=$(realpath "$f")
  local f_dir=$(dirname "$f")

  local tmr_dir="$f_dir/.backup/tmr"
  mkdir -p "$tmr_dir"

  echo "$tmr_dir/$(basename $f).1 $tmr_dir/$(basename $f).2"
}

# 获取添加了appid的三模备份内容
_get_tmr_path2() {
  local f=$1

  f=$(realpath "$f")
  local f_dir=$(dirname "$f")

  local tmr_dir="$f_dir/.${appid}_backup/tmr"
  mkdir -p "$tmr_dir"

  echo "$tmr_dir/$(basename $f).1 $tmr_dir/$(basename $f).2"
}

# 三模创建
_do_tmr() {
  local f=$1
  local p2=$2
  local p3=$3

  if [ ! -f "$p2" ] || [ ! -f "$p3" ]; then
    mkdir -p "$(dirname "$p2")" "$(dirname "$p3")"
    cp -f "$f" "$p2"
    cp -f "$f" "$p3"
  fi
}

# 三模一致性检查
_tmr_chk() {
  local p1=$1
  local p2=$2
  local p3=$3
  local chk_time=$4

  if [ "$chk_time" -eq 0 ]; then
    return 1
  fi

  local dgst1=$(md5sum "$p1" | awk '{print $1}')
  local dgst2=$(md5sum "$p2" | awk '{print $1}')
  local dgst3=$(md5sum "$p3" | awk '{print $1}')

  if [ "$dgst1" = "$dgst2" ] && [ "$dgst2" = "$dgst3" ]; then
    echo "$p1"
  elif [ "$dgst1" = "$dgst2" ] && [ "$dgst2" != "$dgst3" ]; then
    cp -f "$p1" "$p3"
    _tmr_chk "$p1" "$p2" "$p3" "$((chk_time - 1))"
    if [ $? != 0 ]; then
      echo "$p3" >&2
      return 1
    fi
  elif [ "$dgst1" != "$dgst2" ] && [ "$dgst2" = "$dgst3" ]; then
    cp -f "$p2" "$p1"
    _tmr_chk "$p1" "$p2" "$p3" "$((chk_time - 1))"
    if [ $? != 0 ]; then
      echo "$p1" >&2
      return 1
    fi
  elif [ "$dgst1" != "$dgst2" ] && [ "$dgst1" = "$dgst3" ]; then
    cp -f "$p1" "$p2"
    _tmr_chk "$p1" "$p2" "$p3" "$((chk_time - 1))"
    if [ $? != 0 ]; then
      echo "$p2" >&2
      return 1
    fi
  else
    echo "cannot determine the valid one" >&2
    return 1
  fi
}

# 内容写入文件
_fwrite() {
  local f=$1
  local msg="$2"
  local append=${3:-0}
  if [ "$append" = 0 ]; then
    echo "$msg" > "$f"
    [ $? -eq 0 ] || return 1
  else
    echo "$msg" >> "$f"
    [ $? -eq 0 ] || return 1
  fi
}

# 读取文件内容
_fread() {
  local f=$1
  cat "$f"
}

# 运行状态记录
_set_state() {
  local state=$1
  _fwrite "$this_path/$fcurrent_state" "$state"
}

# 遥测数据获取
getteledata(){
  local opr_log="$this_path/$flog_opr"
  if [ ! -s "$opr_log" ]; then
    echo ""FFH $(process_ip_route_result_to_hex) $(fm_print)""
    return 0
  fi

  local ret
  ret=$(_fread "$opr_log"| tail -1)
  [ $? -eq 0 ] || return 1
  
  echo $ret $(process_ip_route_result_to_hex) $(fm_print)
}

# 监控S-FC进程状态
check_process_status() {
    # 定义进程名称
    local main_path=$(_getpath 1)
    local process1="${main_path}/sfc/bin/amf"
    local process2="${main_path}/sfc/bin/redis-server 127.0.0.1:7000"
    local process3="${main_path}/support/s-5gc-support"

    # 定义一个函数用于检查单个进程是否运行
    check_process() {
        pgrep -x "$1" > /dev/null 2>&1
        return $?
    }

    # 检查三个进程的状态
    check_process "$process1"
    local status1=$?
    check_process "$process2"
    local status2=$?
    check_process "$process3"
    local status3=$?

    # 根据三个进程的状态返回不同的结果
    if [ $status1 -eq 0 ] && [ $status2 -eq 0 ] && [ $status3 -eq 0 ]; then
        echo "1110"  # 所有进程都启动
    elif [ $status1 -eq 0 ] && [ $status2 -eq 0 ]; then
        echo "1100"  # amf 和 redis-server 启动
    elif [ $status1 -eq 0 ] && [ $status3 -eq 0 ]; then
        echo "1010"  # amf 和 s-5gc-support 启动
    elif [ $status2 -eq 0 ] && [ $status3 -eq 0 ]; then
        echo "0110"  # redis-server 和 s-5gc-support 启动
    elif [ $status1 -eq 0 ]; then
        echo "1000"  # 只有 amf 启动
    elif [ $status2 -eq 0 ]; then
        echo "0100"  # 只有 redis-server 启动
    elif [ $status3 -eq 0 ]; then
        echo "0010"  # 只有 s-5gc-support 启动
    else
        echo "0000"  # 所有进程都没有启动
    fi
}

check_ip_and_route() {
    # 定义N2 IP地址和两个路由
    local n2_ip="2420:aaaa:203:5:2:100:0:2/112"  # N2 IP 地址
    local gnb_route="2420:aaaa:203:5:1:100::/112 via 2420:aaaa:203:5:2:100:0:1 dev bond0.1000" #基站路由
    local omc_route="default via 2420:aaaa:203:5:6::1 dev bond0.1001" #omc默认路由

    # 检查N2 IP地址是否存在，并指定网口为bond0.1000
    ip -6 addr show dev bond0.1000 | grep -q "$n2_ip"
    local n2_ip_status=$?

    # 检查gnb路由是否存在
    ip -6 route show | grep -q "$gnb_route"
    local gnb_route_status=$?

    # 检查omc路由是否存在
    ip -6 route show | grep -q "$omc_route"
    local omc_route_status=$?

    # 根据三个条件的状态组合生成七种可能的结果
    # 结果格式：n2_ip_status, gnb_route_status, omc_route_status
    result="$n2_ip_status$gnb_route_status$omc_route_status"

    # 输出并返回相应的状态
    case "$result" in
        111)
            echo "0000"  # N2 IP 不存在，gnb 路由不匹配，omc 路由不匹配
            ;;
        110)
            echo "0010"  # N2 IP 不存在，gnb 路由不匹配，omc 路由匹配
            ;;
        101)
            echo "0100"  # N2 IP 不存在，gnb 路由匹配，omc 路由不匹配
            ;;
        100)
            echo "0110"  # N2 IP 不存在，gnb 路由匹配，omc 路由匹配
            ;;
        011)
            echo "1000"  # N2 IP 存在，gnb 路由不匹配，omc 路由不匹配
            ;;
        010)
            echo "1010"  # N2 IP 存在，gnb 路由不匹配，omc 路由匹配
            ;;
        001)
            echo "1100"  # N2 IP 存在，gnb 路由匹配，omc 路由不匹配
            ;;
        000)
            echo "1110"  # N2 IP 存在，gnb 路由匹配，omc 路由匹配
            ;;
    esac
}

# 将检查进程与路由地址的两个二进制值结果拼接并转换为十六进制
process_ip_route_result_to_hex() {
    # 接收两个二进制字符串作为参数
    local check_process_status_value=$(check_process_status)
    local check_ip_and_route_value=$(check_ip_and_route)

    # 拼接二进制字符串
    local combined_value="$check_process_status_value$check_ip_and_route_value"

    # 将拼接后的二进制字符串转换为十六进制
    local hex_value=$(echo "obase=16; ibase=2; $combined_value" | bc)

    # 输出十六进制结果
    echo "$hex_value"
}

fm_print() {
  # 定义要检查的目录
  dir="/var/5gcsup/sfc/fm/"

  # 初始化状态
  sctp_shutdown_fm=0
  mac_failure_fm=0
  pdu_failure_fm=0
  illegal_ue_fm=0

  # 遍历目录下所有的 .json 文件
  for json_file in "$dir"*.json; do
    if [[ -f "$json_file" ]]; then
      # 查找文件中的 "causeID" 并设置对应的状态
      if grep -q '"causeID":"3"' "$json_file"; then
        sctp_shutdown_fm=1
      fi
      if grep -q '"causeID":"4"' "$json_file"; then
        mac_failure_fm=1
      fi
      if grep -q '"causeID":"5"' "$json_file"; then
        pdu_failure_fm=1
      fi
      if grep -q '"causeID":"6"' "$json_file"; then
        illegal_ue_fm=1
      fi
    fi
  done

  # 拼接二进制字符串
  local combined_value="$sctp_shutdown_fm$mac_failure_fm$pdu_failure_fm$illegal_ue_fm"0000

  # 将拼接后的二进制字符串转换为十六进制
  local hex_value=$(echo "obase=16; ibase=2; $combined_value" | bc)

  # 输出十六进制结果
  echo "$hex_value"
}


$@